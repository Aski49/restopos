-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2026 at 10:54 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restopos`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(150) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `module` varchar(50) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `user_id`, `user_name`, `action`, `module`, `details`, `ip_address`, `created_at`) VALUES
(1, 1, 'Administrator', 'Logged In', 'auth', 'Administrator (admin) signed in', '::1', '2026-06-23 03:49:09'),
(2, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #1 → confirmed', '::1', '2026-06-23 03:50:45'),
(3, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #1 → preparing', '::1', '2026-06-23 03:51:11'),
(4, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #1 → ready', '::1', '2026-06-23 03:51:13'),
(5, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #1 → completed', '::1', '2026-06-23 03:51:14'),
(6, 1, 'Administrator', 'Settled Bill', 'pos', 'Bill B-20260623-0001 — Rs. 950.40 via Cash', '::1', '2026-06-23 03:51:59'),
(7, 1, 'Administrator', 'Logged In', 'auth', 'Administrator (admin) signed in', '::1', '2026-06-23 03:58:43'),
(8, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #2 → confirmed', '::1', '2026-06-23 03:59:25'),
(9, 1, 'Administrator', 'Auto-Created Bill', 'online_orders', 'Bill ONL-20260623-0002 (Cash) created from online order ONL-20260623-3885', '::1', '2026-06-23 03:59:25'),
(10, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #2 → preparing', '::1', '2026-06-23 03:59:26'),
(11, 1, 'Administrator', 'Deleted Bill', 'bills', 'Bill B-20260623-0001 permanently deleted', '::1', '2026-06-23 04:00:00'),
(12, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #2 → ready', '::1', '2026-06-23 04:01:43'),
(13, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #2 → completed', '::1', '2026-06-23 04:01:44'),
(14, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #3 → confirmed', '::1', '2026-06-23 04:06:03'),
(15, 1, 'Administrator', 'Auto-Created Bill', 'online_orders', 'Bill ONL-20260623-0003 (Card) created from online order ONL-20260623-3258', '::1', '2026-06-23 04:06:04'),
(16, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #3 → preparing', '::1', '2026-06-23 04:06:04'),
(17, 1, 'Administrator', 'Logged In', 'auth', 'Administrator (admin) signed in', '::1', '2026-06-23 07:53:38'),
(18, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #4 → confirmed', '::1', '2026-06-23 07:54:35'),
(19, 1, 'Administrator', 'Auto-Created Bill', 'online_orders', 'Bill ONL-20260623-0004 (Cash) created from online order ONL-20260623-2181', '::1', '2026-06-23 07:54:35'),
(20, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #4 → preparing', '::1', '2026-06-23 07:54:37'),
(21, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #4 → ready', '::1', '2026-06-23 07:54:52'),
(22, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #3 → ready', '::1', '2026-06-23 07:54:53'),
(23, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #4 → completed', '::1', '2026-06-23 07:54:54'),
(24, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #3 → completed', '::1', '2026-06-23 07:54:55'),
(25, 1, 'Administrator', 'Deleted Bill', 'bills', 'Bill ONL-20260623-0004 permanently deleted', '::1', '2026-06-23 07:55:08'),
(26, 1, 'Administrator', 'Deleted Bill', 'bills', 'Bill ONL-20260623-0003 permanently deleted', '::1', '2026-06-23 07:55:11'),
(27, 1, 'Administrator', 'Deleted Bill', 'bills', 'Bill ONL-20260623-0002 permanently deleted', '::1', '2026-06-23 07:55:13'),
(28, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #5 → cancelled', '::1', '2026-06-23 08:03:18'),
(29, 1, 'Administrator', 'Logged In', 'auth', 'Administrator (admin) signed in', '::1', '2026-06-23 08:13:33'),
(30, 1, 'Administrator', 'Deleted Online Order', 'online_orders', 'Order ONL-20260623-4184 deleted', '::1', '2026-06-23 08:16:08'),
(31, 1, 'Administrator', 'Deleted Online Order', 'online_orders', 'Order ONL-20260623-2181 deleted', '::1', '2026-06-23 08:16:10'),
(32, 1, 'Administrator', 'Deleted Online Order', 'online_orders', 'Order ONL-20260623-3258 deleted', '::1', '2026-06-23 08:16:13'),
(33, 1, 'Administrator', 'Deleted Online Order', 'online_orders', 'Order ONL-20260623-3885 deleted', '::1', '2026-06-23 08:16:15'),
(34, 1, 'Administrator', 'Deleted Online Order', 'online_orders', 'Order ONL-20260623-9400 deleted', '::1', '2026-06-23 08:16:17'),
(35, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #6 → confirmed', '::1', '2026-06-23 08:16:18'),
(36, 1, 'Administrator', 'Auto-Created Bill', 'online_orders', 'Bill ONL-20260623-0006 (Cash) from ONL-20260623-3424', '::1', '2026-06-23 08:16:18'),
(37, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #6 → preparing', '::1', '2026-06-23 08:16:20'),
(38, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #6 → ready', '::1', '2026-06-23 08:16:22'),
(39, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #6 → completed', '::1', '2026-06-23 08:16:23'),
(40, 1, 'Administrator', 'Logged In', 'auth', 'Administrator (admin) signed in', '::1', '2026-06-23 08:36:51'),
(41, 1, 'Administrator', 'Deleted Online Order', 'online_orders', 'Order ONL-20260623-3424 deleted', '::1', '2026-06-23 08:38:47'),
(42, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #7 → confirmed', '::1', '2026-06-23 08:41:42'),
(43, 1, 'Administrator', 'Auto-Created Bill', 'online_orders', 'Bill ONL-20260623-0007 (Cash) from ONL-20260623-8385', '::1', '2026-06-23 08:41:42'),
(44, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #7 → preparing', '::1', '2026-06-23 08:41:44'),
(45, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #7 → ready', '::1', '2026-06-23 08:41:45'),
(46, 1, 'Administrator', 'Updated Online Order', 'online_orders', 'Order #7 → completed', '::1', '2026-06-23 08:41:47'),
(47, 1, 'Administrator', 'Logged Out', 'auth', 'Administrator signed out', '::1', '2026-06-23 08:46:15'),
(48, 3, 'Cashier', 'Logged In', 'auth', 'Cashier (cashier) signed in', '::1', '2026-06-23 08:46:21'),
(49, 3, 'Cashier', 'Logged Out', 'auth', 'Cashier signed out', '::1', '2026-06-23 08:46:40'),
(50, 5, 'Aski Ahamed', 'Logged In', 'auth', 'Aski Ahamed (admin) signed in', '::1', '2026-06-23 08:46:47'),
(51, 1, 'Administrator', 'Logged In', 'auth', 'Administrator (admin) signed in', '::1', '2026-06-23 08:51:05'),
(52, 1, 'Administrator', 'Deleted Online Order', 'online_orders', 'Order ONL-20260623-9876 deleted', '::1', '2026-06-23 08:52:13'),
(53, 1, 'Administrator', 'Deleted Online Order', 'online_orders', 'Order ONL-20260623-8385 deleted', '::1', '2026-06-23 08:52:16'),
(54, 1, 'Administrator', 'Deleted Reservation', 'reservations', 'Reservation for Ahmed Azim', '::1', '2026-06-23 08:53:42'),
(55, 1, 'Administrator', 'Deleted Reservation', 'reservations', 'Reservation for Ahmed Azim', '::1', '2026-06-23 08:53:44'),
(56, 1, 'Administrator', 'Deleted Online Order', 'online_orders', 'Order ONL-20260623-5228 deleted', '::1', '2026-06-23 08:53:48');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `att_date` date NOT NULL,
  `status` enum('Present','Absent','Half Day','Leave') DEFAULT 'Present',
  `time_in` time DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  `overtime_hours` decimal(4,2) DEFAULT 0.00,
  `notes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `employee_id`, `att_date`, `status`, `time_in`, `time_out`, `overtime_hours`, `notes`) VALUES
(1, 4, '2026-06-23', 'Present', '09:00:00', '22:00:00', 0.00, ''),
(2, 4, '2026-06-05', 'Absent', '09:00:00', '22:00:00', 0.00, ''),
(3, 4, '2026-06-22', 'Present', '09:00:00', '22:00:00', 4.00, NULL),
(4, 1, '2026-06-22', 'Present', '09:09:00', '20:00:00', 1.75, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_no` varchar(50) DEFAULT NULL,
  `account_name` varchar(150) DEFAULT NULL,
  `balance` decimal(12,2) DEFAULT 0.00,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bank_accounts`
--

INSERT INTO `bank_accounts` (`id`, `bank_name`, `account_no`, `account_name`, `balance`, `active`, `created_at`) VALUES
(1, 'Commercial Bank', '1234567890', 'My Restaurant', 285000.00, 1, '2026-06-23 03:48:36'),
(2, 'BOC', '0987654321', 'My Restaurant', 100000.00, 1, '2026-06-23 03:48:36');

-- --------------------------------------------------------

--
-- Table structure for table `bank_transactions`
--

CREATE TABLE `bank_transactions` (
  `id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `txn_date` date NOT NULL,
  `type` enum('deposit','withdrawal','transfer') DEFAULT 'deposit',
  `amount` decimal(10,2) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `id` int(11) NOT NULL,
  `bill_no` varchar(30) NOT NULL,
  `order_type` enum('Dine-In','Takeaway','Uber Eats','PickMe','Delivery') DEFAULT 'Dine-In',
  `table_no` varchar(10) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT 0.00,
  `service_charge` decimal(10,2) DEFAULT 0.00,
  `discount_pct` decimal(5,2) DEFAULT 0.00,
  `discount_amt` decimal(10,2) DEFAULT 0.00,
  `tax_amt` decimal(10,2) DEFAULT 0.00,
  `total` decimal(10,2) DEFAULT 0.00,
  `payment_method` varchar(50) DEFAULT 'Cash',
  `cash_given` decimal(10,2) DEFAULT 0.00,
  `change_amt` decimal(10,2) DEFAULT 0.00,
  `status` enum('settled','voided','pending') DEFAULT 'settled',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`id`, `bill_no`, `order_type`, `table_no`, `subtotal`, `service_charge`, `discount_pct`, `discount_amt`, `tax_amt`, `total`, `payment_method`, `cash_given`, `change_amt`, `status`, `notes`, `created_by`, `created_at`) VALUES
(5, 'ONL-20260623-0006', 'Takeaway', 'Online Ord', 950.00, 95.00, 0.00, 0.00, 83.60, 1128.60, 'Cash', 0.00, 0.00, 'settled', 'Online Order — Customer: aski | ONL-20260623-3424', 1, '2026-06-23 08:16:18'),
(6, 'ONL-20260623-0007', 'Takeaway', 'Online Ord', 950.00, 95.00, 0.00, 0.00, 83.60, 1128.60, 'Cash', 0.00, 0.00, 'settled', 'Online Order — Customer: aski | ONL-20260623-8385', 1, '2026-06-23 08:41:42');

-- --------------------------------------------------------

--
-- Table structure for table `bill_items`
--

CREATE TABLE `bill_items` (
  `id` int(11) NOT NULL,
  `bill_id` int(11) NOT NULL,
  `menu_item_id` int(11) DEFAULT NULL,
  `item_name` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 1,
  `line_total` decimal(10,2) NOT NULL,
  `kitchen_status` enum('pending','preparing','ready','served') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bill_items`
--

INSERT INTO `bill_items` (`id`, `bill_id`, `menu_item_id`, `item_name`, `price`, `qty`, `line_total`, `kitchen_status`) VALUES
(5, 5, 1, 'Chicken Rice', 450.00, 1, 450.00, 'served'),
(6, 5, 2, 'Fish Curry Rice', 500.00, 1, 500.00, 'served'),
(7, 6, 1, 'Chicken Rice', 450.00, 1, 450.00, 'served'),
(8, 6, 2, 'Fish Curry Rice', 500.00, 1, 500.00, 'served');

-- --------------------------------------------------------

--
-- Table structure for table `bill_promotions`
--

CREATE TABLE `bill_promotions` (
  `id` int(11) NOT NULL,
  `bill_id` int(11) NOT NULL,
  `promo_id` int(11) DEFAULT NULL,
  `promo_name` varchar(150) DEFAULT NULL,
  `discount_amt` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `debtors`
--

CREATE TABLE `debtors` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `credit_limit` decimal(10,2) DEFAULT 0.00,
  `outstanding` decimal(10,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `debtors`
--

INSERT INTO `debtors` (`id`, `name`, `phone`, `email`, `credit_limit`, `outstanding`, `notes`, `active`, `created_at`) VALUES
(1, 'ABC Company', '+94112345678', NULL, 0.00, 28500.00, NULL, 1, '2026-06-23 03:48:36'),
(2, 'XYZ Office', '+94113456789', NULL, 0.00, 12000.00, NULL, 1, '2026-06-23 03:48:36'),
(3, 'Colombo Hotel', '+94114567890', NULL, 0.00, 67000.00, NULL, 1, '2026-06-23 03:48:36'),
(4, 'Mr. Pradeep', '+94775678901', NULL, 0.00, 3500.00, NULL, 1, '2026-06-23 03:48:36');

-- --------------------------------------------------------

--
-- Table structure for table `debtor_payments`
--

CREATE TABLE `debtor_payments` (
  `id` int(11) NOT NULL,
  `debtor_id` int(11) NOT NULL,
  `bill_id` int(11) DEFAULT NULL,
  `txn_date` date NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` enum('charge','payment') DEFAULT 'charge',
  `notes` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `nic` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `basic_salary` decimal(10,2) DEFAULT 0.00,
  `allowances` decimal(10,2) DEFAULT 0.00,
  `epf_applicable` tinyint(1) DEFAULT 1,
  `joined_date` date DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `nic`, `phone`, `position`, `basic_salary`, `allowances`, `epf_applicable`, `joined_date`, `active`, `created_at`) VALUES
(1, 'Kasun Perera', '199012345678', '+94771234567', 'Manager', 65000.00, 8000.00, 1, '2022-01-01', 1, '2026-06-23 03:48:35'),
(2, 'Nimali Silva', '199534567890', '+94772345678', 'Cashier', 42000.00, 5000.00, 1, '2022-03-15', 1, '2026-06-23 03:48:35'),
(3, 'Thilina Fernando', '198890123456', '+94773456789', 'Chef', 55000.00, 7000.00, 1, '2021-06-01', 1, '2026-06-23 03:48:35'),
(4, 'Chamari Jayawardena', '200012345670', '+94774567890', 'Waiter', 35000.00, 4000.00, 1, '2023-01-10', 1, '2026-06-23 03:48:35'),
(5, 'Ruwan Bandara', '199678901234', '+94775678901', 'Kitchen Helper', 28000.00, 3000.00, 0, '2023-05-20', 1, '2026-06-23 03:48:35');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `expense_date` date NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('Cash','Card','Bank Transfer') DEFAULT 'Cash',
  `supplier` varchar(150) DEFAULT NULL,
  `invoice_no` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_categories`
--

CREATE TABLE `expense_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expense_categories`
--

INSERT INTO `expense_categories` (`id`, `name`, `active`) VALUES
(1, 'Utilities', 1),
(2, 'Rent', 1),
(3, 'Purchases', 1),
(4, 'Transport', 1),
(5, 'Maintenance', 1),
(6, 'Marketing', 1),
(7, 'Salaries', 1),
(8, 'Miscellaneous', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inventory_categories`
--

CREATE TABLE `inventory_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_categories`
--

INSERT INTO `inventory_categories` (`id`, `name`) VALUES
(1, 'Grains'),
(2, 'Proteins'),
(3, 'Oils'),
(4, 'Produce'),
(5, 'Dairy'),
(6, 'Beverages'),
(7, 'Utilities');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_items`
--

CREATE TABLE `inventory_items` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `unit` varchar(20) DEFAULT 'kg',
  `qty` decimal(10,3) DEFAULT 0.000,
  `min_qty` decimal(10,3) DEFAULT 0.000,
  `unit_cost` decimal(10,2) DEFAULT 0.00,
  `active` tinyint(1) DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_items`
--

INSERT INTO `inventory_items` (`id`, `category_id`, `name`, `unit`, `qty`, `min_qty`, `unit_cost`, `active`, `updated_at`) VALUES
(1, 1, 'Rice', 'kg', 45.000, 20.000, 180.00, 1, '2026-06-23 03:48:33'),
(2, 2, 'Chicken', 'kg', 15.000, 10.000, 1100.00, 1, '2026-06-23 03:48:33'),
(3, 2, 'Fish', 'kg', 8.000, 8.000, 900.00, 1, '2026-06-23 03:48:33'),
(4, 1, 'Flour', 'kg', 30.000, 15.000, 210.00, 1, '2026-06-23 03:48:33'),
(5, 3, 'Coconut Oil', 'L', 12.000, 5.000, 520.00, 1, '2026-06-23 03:48:33'),
(6, 4, 'Vegetables', 'kg', 10.000, 10.000, 150.00, 1, '2026-06-23 03:48:33'),
(7, 6, 'Tea Packets', 'packs', 5.000, 5.000, 850.00, 1, '2026-06-23 03:48:33'),
(8, 7, 'Gas Cylinders', 'cylinders', 2.000, 2.000, 4500.00, 1, '2026-06-23 03:48:33');

-- --------------------------------------------------------

--
-- Table structure for table `menu_categories`
--

CREATE TABLE `menu_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_categories`
--

INSERT INTO `menu_categories` (`id`, `name`, `sort_order`, `active`) VALUES
(1, 'Rice Meals', 1, 1),
(2, 'Kottu', 2, 1),
(3, 'Noodles', 3, 1),
(4, 'Beverages', 4, 1),
(5, 'Snacks', 5, 1),
(6, 'Desserts', 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `category_id`, `name`, `price`, `description`, `image`, `active`, `created_at`) VALUES
(1, 1, 'Chicken Rice', 450.00, '', 'item_6a3a4936d48767.26344967.jfif', 1, '2026-06-23 03:48:31'),
(2, 1, 'Fish Curry Rice', 500.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(3, 1, 'Fried Rice', 480.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(4, 1, 'Veggie Rice', 350.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(5, 2, 'Veggie Kottu', 380.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(6, 2, 'Egg Kottu', 420.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(7, 2, 'Chicken Kottu', 520.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(8, 2, 'Cheese Kottu', 580.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(9, 2, 'Prawn Kottu', 680.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(10, 3, 'Veg Noodles', 380.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(11, 3, 'Chicken Noodles', 480.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(12, 4, 'Plain Tea', 80.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(13, 4, 'Milk Tea', 120.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(14, 4, 'Mango Juice', 200.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(15, 4, 'Soft Drink', 150.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(16, 4, 'Water Bottle', 80.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(17, 5, 'Chicken Sandwich', 280.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(18, 5, 'Samosa', 60.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(19, 5, 'Short Eats', 45.00, NULL, NULL, 1, '2026-06-23 03:48:31'),
(20, 5, 'Garlic Bread', 150.00, NULL, NULL, 1, '2026-06-23 03:48:31');

-- --------------------------------------------------------

--
-- Table structure for table `menu_item_recipes`
--

CREATE TABLE `menu_item_recipes` (
  `id` int(11) NOT NULL,
  `menu_item_id` int(11) NOT NULL,
  `inventory_item_id` int(11) NOT NULL,
  `qty_per_unit` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `online_orders`
--

CREATE TABLE `online_orders` (
  `id` int(11) NOT NULL,
  `order_no` varchar(30) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_phone` varchar(50) NOT NULL,
  `customer_note` text DEFAULT NULL,
  `order_type` enum('takeaway','card','bank_transfer') DEFAULT 'takeaway',
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `service_charge` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('new','confirmed','preparing','ready','completed','cancelled') DEFAULT 'new',
  `seen` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `online_order_items`
--

CREATE TABLE `online_order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `menu_item_id` int(11) DEFAULT NULL,
  `item_name` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 1,
  `line_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE `payroll` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `pay_month` date NOT NULL,
  `basic_salary` decimal(10,2) DEFAULT 0.00,
  `allowances` decimal(10,2) DEFAULT 0.00,
  `overtime_pay` decimal(10,2) DEFAULT 0.00,
  `bonus` decimal(10,2) DEFAULT 0.00,
  `gross_salary` decimal(10,2) DEFAULT 0.00,
  `salary_advance` decimal(10,2) DEFAULT 0.00,
  `other_deductions` decimal(10,2) DEFAULT 0.00,
  `epf_employee` decimal(10,2) DEFAULT 0.00,
  `epf_employer` decimal(10,2) DEFAULT 0.00,
  `etf_employer` decimal(10,2) DEFAULT 0.00,
  `net_salary` decimal(10,2) DEFAULT 0.00,
  `status` enum('draft','approved','paid') DEFAULT 'draft',
  `paid_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `promotions`
--

CREATE TABLE `promotions` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `promo_type` enum('percent_off','fixed_off','buy_x_get_y') NOT NULL DEFAULT 'percent_off',
  `discount_value` decimal(10,2) DEFAULT 0.00,
  `buy_qty` int(11) DEFAULT 1,
  `get_qty` int(11) DEFAULT 1,
  `applies_to` enum('all','category','item') DEFAULT 'all',
  `applies_id` int(11) DEFAULT NULL,
  `min_order_amount` decimal(10,2) DEFAULT 0.00,
  `valid_from` date DEFAULT NULL,
  `valid_to` date DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `promotions`
--

INSERT INTO `promotions` (`id`, `name`, `description`, `promo_type`, `discount_value`, `buy_qty`, `get_qty`, `applies_to`, `applies_id`, `min_order_amount`, `valid_from`, `valid_to`, `active`, `created_at`) VALUES
(1, '10% Off All Orders', 'Get 10% discount on your entire bill', 'percent_off', 10.00, 1, 1, 'all', NULL, 0.00, '2026-06-23', '2026-07-23', 1, '2026-06-23 03:48:32'),
(2, 'Happy Hour Rs.100 Off', 'Rs. 100 off on orders above Rs. 500', 'fixed_off', 100.00, 1, 1, 'all', NULL, 0.00, '2026-06-23', '2026-07-23', 1, '2026-06-23 03:48:32');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `res_date` date NOT NULL,
  `res_time` time NOT NULL,
  `res_end_time` time DEFAULT NULL,
  `pax` int(11) NOT NULL DEFAULT 1,
  `location` varchar(150) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('Confirmed','Pending','Cancelled','Completed') DEFAULT 'Confirmed',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES
(1, 'business_name', 'Cove Cafe & Lounge', '2026-06-23 08:19:18'),
(2, 'address', 'Kirulapane, Sri Lanka', '2026-06-23 08:19:18'),
(3, 'phone', '+94 11 234 5678', '2026-06-23 03:48:31'),
(4, 'email', 'info@myrestaurant.lk', '2026-06-23 03:48:31'),
(5, 'service_charge_pct', '10', '2026-06-23 03:48:31'),
(6, 'tax_pct', '8', '2026-06-23 03:48:31'),
(7, 'ubereats_commission', '30', '2026-06-23 03:48:31'),
(8, 'pickme_commission', '28', '2026-06-23 03:48:31'),
(9, 'currency', 'Rs.', '2026-06-23 03:48:31');

-- --------------------------------------------------------

--
-- Table structure for table `stock_purchases`
--

CREATE TABLE `stock_purchases` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `qty` decimal(10,3) NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `supplier` varchar(150) DEFAULT NULL,
  `invoice_no` varchar(100) DEFAULT NULL,
  `payment_method` enum('Cash','Card','Bank Transfer') DEFAULT 'Cash',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock_usage`
--

CREATE TABLE `stock_usage` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `usage_date` date NOT NULL,
  `qty` decimal(10,3) NOT NULL,
  `source` enum('bill','manual') DEFAULT 'bill',
  `bill_id` int(11) DEFAULT NULL,
  `menu_item_name` varchar(150) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'cashier',
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `role`, `active`, `created_at`) VALUES
(1, 'Administrator', 'admin', 'admin123', 'admin', 1, '2026-06-23 03:48:30'),
(2, 'Manager', 'manager', 'manager123', 'manager', 1, '2026-06-23 03:48:30'),
(3, 'Cashier', 'cashier', 'cashier123', 'cashier', 1, '2026-06-23 03:48:30'),
(4, 'Kitchen Boy', 'kitchen', 'kitchen123', 'kitchen', 1, '2026-06-23 03:48:30'),
(5, 'Aski Ahamed', 'aski', 'aski123', 'admin', 1, '2026-06-23 08:46:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_emp_date` (`employee_id`,`att_date`);

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank_transactions`
--
ALTER TABLE `bank_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_id` (`account_id`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bill_no` (`bill_no`);

--
-- Indexes for table `bill_items`
--
ALTER TABLE `bill_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bill_id` (`bill_id`);

--
-- Indexes for table `bill_promotions`
--
ALTER TABLE `bill_promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bill_id` (`bill_id`);

--
-- Indexes for table `debtors`
--
ALTER TABLE `debtors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `debtor_payments`
--
ALTER TABLE `debtor_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `debtor_id` (`debtor_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_categories`
--
ALTER TABLE `inventory_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_items`
--
ALTER TABLE `inventory_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `menu_categories`
--
ALTER TABLE `menu_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `menu_item_recipes`
--
ALTER TABLE `menu_item_recipes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_menu_inv` (`menu_item_id`,`inventory_item_id`),
  ADD KEY `inventory_item_id` (`inventory_item_id`);

--
-- Indexes for table `online_orders`
--
ALTER TABLE `online_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_no` (`order_no`);

--
-- Indexes for table `online_order_items`
--
ALTER TABLE `online_order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_emp_month` (`employee_id`,`pay_month`);

--
-- Indexes for table `promotions`
--
ALTER TABLE `promotions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `stock_purchases`
--
ALTER TABLE `stock_purchases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `stock_usage`
--
ALTER TABLE `stock_usage`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bank_transactions`
--
ALTER TABLE `bank_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `bill_items`
--
ALTER TABLE `bill_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `bill_promotions`
--
ALTER TABLE `bill_promotions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `debtors`
--
ALTER TABLE `debtors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `debtor_payments`
--
ALTER TABLE `debtor_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expense_categories`
--
ALTER TABLE `expense_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `inventory_categories`
--
ALTER TABLE `inventory_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `inventory_items`
--
ALTER TABLE `inventory_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `menu_categories`
--
ALTER TABLE `menu_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `menu_item_recipes`
--
ALTER TABLE `menu_item_recipes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `online_orders`
--
ALTER TABLE `online_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `online_order_items`
--
ALTER TABLE `online_order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `payroll`
--
ALTER TABLE `payroll`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `promotions`
--
ALTER TABLE `promotions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `stock_purchases`
--
ALTER TABLE `stock_purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stock_usage`
--
ALTER TABLE `stock_usage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`);

--
-- Constraints for table `bank_transactions`
--
ALTER TABLE `bank_transactions`
  ADD CONSTRAINT `bank_transactions_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `bank_accounts` (`id`);

--
-- Constraints for table `bill_items`
--
ALTER TABLE `bill_items`
  ADD CONSTRAINT `bill_items_ibfk_1` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bill_promotions`
--
ALTER TABLE `bill_promotions`
  ADD CONSTRAINT `bill_promotions_ibfk_1` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `debtor_payments`
--
ALTER TABLE `debtor_payments`
  ADD CONSTRAINT `debtor_payments_ibfk_1` FOREIGN KEY (`debtor_id`) REFERENCES `debtors` (`id`);

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `expense_categories` (`id`);

--
-- Constraints for table `inventory_items`
--
ALTER TABLE `inventory_items`
  ADD CONSTRAINT `inventory_items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `inventory_categories` (`id`);

--
-- Constraints for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `menu_items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `menu_categories` (`id`);

--
-- Constraints for table `menu_item_recipes`
--
ALTER TABLE `menu_item_recipes`
  ADD CONSTRAINT `menu_item_recipes_ibfk_1` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `menu_item_recipes_ibfk_2` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `online_order_items`
--
ALTER TABLE `online_order_items`
  ADD CONSTRAINT `online_order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `online_orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payroll`
--
ALTER TABLE `payroll`
  ADD CONSTRAINT `payroll_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`);

--
-- Constraints for table `stock_purchases`
--
ALTER TABLE `stock_purchases`
  ADD CONSTRAINT `stock_purchases_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `inventory_items` (`id`);

--
-- Constraints for table `stock_usage`
--
ALTER TABLE `stock_usage`
  ADD CONSTRAINT `stock_usage_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `inventory_items` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
