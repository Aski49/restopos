<?php
require_once 'includes/config.php';
$db = getDB();

$bizName  = getSetting('business_name', 'My Restaurant');
$bizAddr  = getSetting('address', 'Colombo, Sri Lanka');
$bizPhone = getSetting('phone', '');
$svcPct   = (float)getSetting('service_charge_pct', '10');
$taxPct   = (float)getSetting('tax_pct', '8');

// ── Handle reservation submission ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['make_reservation'])) {
    header('Content-Type: application/json');
    $rName  = trim($_POST['res_name'] ?? '');
    $rPhone = trim($_POST['res_phone'] ?? '');
    $rDate  = $_POST['res_date'] ?? '';
    $rTime  = $_POST['res_time'] ?? '';
    $rEnd   = !empty($_POST['res_end_time']) ? $_POST['res_end_time'] : null;
    $rPax   = (int)($_POST['res_pax'] ?? 2);
    $rLoc   = trim($_POST['res_location'] ?? '');
    $rNote  = trim($_POST['res_note'] ?? '');
    if (!$rName || !$rPhone || !$rDate || !$rTime) {
        echo json_encode(['ok'=>false,'error'=>'Please fill all required fields.']); exit;
    }
    try {
        $db->prepare("INSERT INTO reservations(customer_name,contact,res_date,res_time,res_end_time,pax,location,notes,status)
                      VALUES(?,?,?,?,?,?,?,?,'Confirmed')")
           ->execute([$rName,$rPhone,$rDate,$rTime,$rEnd,$rPax,$rLoc,$rNote]);
        echo json_encode(['ok'=>true,'name'=>$rName,'date'=>date('d M Y',strtotime($rDate)),'time'=>date('h:i A',strtotime($rTime))]); exit;
    } catch (Exception $e) {
        echo json_encode(['ok'=>false,'error'=>'Reservation failed. Please call us directly.']); exit;
    }
}

// ── Handle order submission ─────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    header('Content-Type: application/json');
    $name    = trim($_POST['customer_name'] ?? '');
    $phone   = trim($_POST['customer_phone'] ?? '');
    $note    = trim($_POST['customer_note'] ?? '');
    $type    = in_array($_POST['order_type'],['takeaway','card','bank_transfer']) ? $_POST['order_type'] : 'takeaway';
    $cartRaw = json_decode($_POST['cart'] ?? '[]', true);
    if (!$name || !$phone || empty($cartRaw)) { echo json_encode(['ok'=>false,'error'=>'Please fill all required fields.']); exit; }
    try {
        $db->beginTransaction();
        $orderNo  = 'ONL-'.date('Ymd').'-'.str_pad(rand(1,9999),4,'0',STR_PAD_LEFT);
        $subtotal = array_sum(array_map(fn($i)=>(float)$i['price']*(int)$i['qty'], $cartRaw));
        $svc      = round($subtotal * $svcPct / 100, 2);
        $tax      = round(($subtotal + $svc) * $taxPct / 100, 2);
        $total    = round($subtotal + $svc + $tax, 2);
        $db->prepare("INSERT INTO online_orders(order_no,customer_name,customer_phone,customer_note,order_type,subtotal,service_charge,tax,total,status,seen) VALUES(?,?,?,?,?,?,?,?,?,'new',0)")
           ->execute([$orderNo,$name,$phone,$note,$type,$subtotal,$svc,$tax,$total]);
        $orderId = $db->lastInsertId();
        $ins = $db->prepare("INSERT INTO online_order_items(order_id,menu_item_id,item_name,price,qty,line_total) VALUES(?,?,?,?,?,?)");
        foreach ($cartRaw as $ci) {
            $ins->execute([$orderId,$ci['id']??null,$ci['name'],$ci['price'],$ci['qty'],(float)$ci['price']*(int)$ci['qty']]);
        }
        $db->commit();
        echo json_encode(['ok'=>true,'order_no'=>$orderNo,'total'=>$total]); exit;
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['ok'=>false,'error'=>'Order failed. Please try again.']); exit;
    }
}

$categories = $db->query("SELECT * FROM menu_categories WHERE active=1 ORDER BY sort_order,name")->fetchAll();
$allItems   = $db->query("SELECT mi.*,mc.name as cat_name FROM menu_items mi JOIN menu_categories mc ON mi.category_id=mc.id WHERE mi.active=1 ORDER BY mc.sort_order,mi.name")->fetchAll();
$byCategory = [];
foreach ($allItems as $it) { $byCategory[$it['category_id']][] = $it; }

$catEmojis=['rice'=>'🍛','kottu'=>'🥘','noodle'=>'🍜','beverage'=>'🥤','drink'=>'🥤','snack'=>'🍟','dessert'=>'🍮','soup'=>'🍲','chicken'=>'🍗','fish'=>'🐟','sea'=>'🦐','veg'=>'🥗','burger'=>'🍔','bread'=>'🍞','short'=>'🥮','pizza'=>'🍕','roti'=>'🫓'];
function catEmoji($n){global $catEmojis;$n=strtolower($n);foreach($catEmojis as $k=>$e){if(str_contains($n,$k))return $e;}return '🍽';}
$PALETTE=['#c8972a','#2e9e72','#2563eb','#7c3aed','#dc2626','#0891b2','#ea580c','#be185d'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=htmlspecialchars($bizName)?> — Menu & Reservations</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;0,900;1,400;1,700&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════
   RESTOPOS — PREMIUM RESTAURANT WEBSITE
   Inspired by chola.lk — dark luxury theme
   ═══════════════════════════════════════════════════════ */
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth;-webkit-tap-highlight-color:transparent}
body{background:#09090f;color:#e8e8f0;font-family:'Inter',sans-serif;overflow-x:hidden}
img{display:block;max-width:100%}
a{text-decoration:none;color:inherit}
button,input,select,textarea{font-family:'Inter',sans-serif}
::-webkit-scrollbar{width:3px}
::-webkit-scrollbar-track{background:#09090f}
::-webkit-scrollbar-thumb{background:#2a2a3a;border-radius:2px}

/* ─── VARS ─────────────────────────────────────────── */
:root{
  --bg:#09090f;
  --s1:#0f0f1a;
  --s2:#141420;
  --card:#181825;
  --border:rgba(255,255,255,.07);
  --text:#e8e8f0;
  --muted:#6b6b8a;
  --gold:#c8972a;
  --gold2:#e8b84b;
  --gold3:#ffd166;
  --green:#10b981;
  --red:#ef4444;
  --r:14px;
}

/* ─── NAVBAR ────────────────────────────────────────── */
.navbar{
  position:fixed;top:0;left:0;right:0;z-index:1000;
  display:flex;align-items:center;justify-content:space-between;
  padding:0 5%;height:68px;
  background:rgba(9,9,15,.85);
  backdrop-filter:blur(24px) saturate(180%);
  border-bottom:1px solid rgba(200,151,42,.12);
  transition:all .3s;
}
.navbar.scrolled{background:rgba(9,9,15,.97);box-shadow:0 4px 32px rgba(0,0,0,.4)}
.nav-brand{
  font-family:'Playfair Display',serif;
  font-size:22px;font-weight:700;color:var(--gold2);
  letter-spacing:.5px;white-space:nowrap;
}
.nav-links{display:flex;align-items:center;gap:6px}
.nav-link{
  padding:8px 16px;border-radius:8px;font-size:13px;font-weight:500;
  color:rgba(232,232,240,.65);transition:.2s;cursor:pointer;background:none;border:none;
}
.nav-link:hover{color:var(--text);background:rgba(255,255,255,.05)}
.nav-link.active{color:var(--gold2)}
.nav-reserve{
  background:linear-gradient(135deg,var(--gold),var(--gold2));
  color:#09090f;font-weight:700;font-size:13px;
  padding:9px 20px;border-radius:100px;border:none;cursor:pointer;transition:.2s;
  white-space:nowrap;
}
.nav-reserve:hover{transform:scale(1.04);box-shadow:0 4px 20px rgba(200,151,42,.35)}
.nav-cart-btn{
  display:flex;align-items:center;gap:7px;
  background:rgba(200,151,42,.1);border:1px solid rgba(200,151,42,.25);
  color:var(--gold2);font-weight:600;font-size:13px;
  padding:8px 16px;border-radius:100px;cursor:pointer;transition:.2s;
  white-space:nowrap;
}
.nav-cart-btn:hover{background:rgba(200,151,42,.18)}
.nav-cart-btn.hidden{display:none}
.nav-badge{background:var(--gold);color:#09090f;border-radius:100px;padding:1px 7px;font-size:11px;font-weight:800}
.hamburger{display:none;flex-direction:column;gap:5px;cursor:pointer;padding:4px;background:none;border:none}
.hamburger span{width:22px;height:2px;background:var(--text);border-radius:1px;transition:.3s}

/* Mobile nav menu */
.mob-menu{
  display:none;position:fixed;top:68px;left:0;right:0;z-index:999;
  background:rgba(9,9,15,.98);border-bottom:1px solid var(--border);
  padding:16px 5% 20px;flex-direction:column;gap:4px;
}
.mob-menu.open{display:flex}
.mob-link{padding:12px 16px;border-radius:8px;font-size:14px;font-weight:500;color:rgba(232,232,240,.8);cursor:pointer;background:none;border:none;text-align:left;width:100%}
.mob-link:hover{background:rgba(255,255,255,.05);color:var(--text)}
.mob-reserve{
  margin-top:8px;width:100%;padding:13px;border-radius:12px;
  background:linear-gradient(135deg,var(--gold),var(--gold2));
  color:#09090f;font-weight:700;font-size:14px;border:none;cursor:pointer;
}

/* ─── HERO ──────────────────────────────────────────── */
.hero{
  min-height:100vh;position:relative;
  display:flex;align-items:center;justify-content:center;
  overflow:hidden;
}
.hero-bg{
  position:absolute;inset:0;z-index:0;
  background:
    linear-gradient(170deg,#12080a 0%,#09090f 35%,#08090f 65%,#090812 100%);
}
.hero-pattern{
  position:absolute;inset:0;z-index:0;opacity:.03;
  background-image:url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23c8972a' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
}
.hero-glow1{position:absolute;width:600px;height:600px;border-radius:50%;filter:blur(120px);background:rgba(200,151,42,.12);top:-150px;left:-100px;z-index:0;pointer-events:none}
.hero-glow2{position:absolute;width:400px;height:400px;border-radius:50%;filter:blur(80px);background:rgba(16,185,129,.08);bottom:-80px;right:-80px;z-index:0;pointer-events:none}

.hero-inner{position:relative;z-index:2;text-align:center;padding:100px 24px 60px;max-width:860px;margin:0 auto}

.hero-badge{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(200,151,42,.1);border:1px solid rgba(200,151,42,.25);
  border-radius:100px;padding:7px 18px;margin-bottom:28px;
  font-size:11px;font-weight:700;color:var(--gold2);letter-spacing:1.5px;text-transform:uppercase;
}
.h-dot{width:7px;height:7px;border-radius:50%;background:var(--green);flex-shrink:0;animation:blink 2s infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}

.hero-title{
  font-family:'Playfair Display',serif;
  font-size:clamp(44px,8vw,88px);
  font-weight:900;line-height:.95;letter-spacing:-2px;margin-bottom:12px;
}
.ht1{
  display:block;
  background:linear-gradient(120deg,#fff 10%,var(--gold) 40%,var(--gold2) 55%,var(--gold3) 70%,#fff 90%);
  background-size:250% auto;
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  animation:shine 6s linear infinite;
}
@keyframes shine{0%{background-position:250% center}100%{background-position:-250% center}}
.ht2{display:block;font-style:italic;font-size:.45em;color:rgba(200,151,42,.45);letter-spacing:2px;margin-top:10px;font-weight:400}

.hero-tagline{
  font-size:clamp(14px,2.5vw,17px);color:rgba(232,232,240,.5);
  font-weight:300;line-height:1.8;margin-bottom:36px;max-width:540px;margin-left:auto;margin-right:auto;
}

.hero-divider{
  display:flex;align-items:center;gap:14px;max-width:240px;margin:0 auto 36px;
}
.hero-divider::before,.hero-divider::after{content:'';flex:1;height:1px;background:linear-gradient(90deg,transparent,rgba(200,151,42,.35),transparent)}
.hero-divider-icon{font-size:16px;color:var(--gold);opacity:.6}

.hero-btns{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-bottom:48px}
.btn-gold{
  display:inline-flex;align-items:center;gap:8px;
  background:linear-gradient(135deg,var(--gold),var(--gold2));
  color:#09090f;font-weight:700;font-size:14px;
  padding:13px 28px;border-radius:100px;border:none;cursor:pointer;
  box-shadow:0 6px 28px rgba(200,151,42,.3);transition:all .3s;
}
.btn-gold:hover{transform:translateY(-3px);box-shadow:0 10px 40px rgba(200,151,42,.45)}
.btn-ghost{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12);
  color:var(--text);font-weight:600;font-size:14px;
  padding:13px 28px;border-radius:100px;cursor:pointer;transition:.3s;
}
.btn-ghost:hover{border-color:rgba(200,151,42,.3);color:var(--gold2);background:rgba(200,151,42,.06)}

.hero-features{
  display:flex;justify-content:center;gap:0;
  background:rgba(255,255,255,.04);border:1px solid var(--border);
  border-radius:16px;overflow:hidden;max-width:580px;margin:0 auto;
}
.hf-item{flex:1;padding:16px 12px;text-align:center;border-right:1px solid var(--border);position:relative}
.hf-item:last-child{border-right:none}
.hf-icon{font-size:22px;margin-bottom:5px}
.hf-label{font-size:10px;color:var(--muted);font-weight:600;letter-spacing:.8px;text-transform:uppercase}

/* ─── ABOUT SECTION ─────────────────────────────────── */
.about-section{
  background:var(--s1);padding:80px 5%;
  border-top:1px solid var(--border);
}
.about-inner{max-width:1100px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center}
.about-tag{font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--gold);margin-bottom:12px}
.about-title{font-family:'Playfair Display',serif;font-size:clamp(28px,4vw,40px);font-weight:700;line-height:1.2;margin-bottom:18px}
.about-text{font-size:14px;color:var(--muted);line-height:1.9;margin-bottom:14px}
.about-list{display:flex;flex-direction:column;gap:10px;margin-bottom:28px}
.about-item{display:flex;align-items:center;gap:10px;font-size:13px;color:rgba(232,232,240,.7)}
.about-item::before{content:'✦';color:var(--gold);font-size:10px;flex-shrink:0}
.about-visual{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.about-card{
  background:var(--card);border:1px solid var(--border);
  border-radius:14px;padding:22px 18px;text-align:center;
}
.about-card-icon{font-size:32px;margin-bottom:8px}
.about-card-num{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;color:var(--gold2);margin-bottom:3px}
.about-card-lbl{font-size:11px;color:var(--muted);font-weight:600;letter-spacing:.5px}

/* ─── CATEGORY NAV ──────────────────────────────────── */
.cat-section{
  position:sticky;top:68px;z-index:800;
  background:rgba(9,9,15,.94);backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
}
.cat-inner{
  max-width:1100px;margin:0 auto;
  display:flex;overflow-x:auto;scrollbar-width:none;
  padding:0 5%;
}
.cat-inner::-webkit-scrollbar{display:none}
.cat-pill{
  flex-shrink:0;display:flex;align-items:center;gap:7px;
  padding:14px 18px;font-size:13px;font-weight:500;color:var(--muted);
  border-bottom:2px solid transparent;cursor:pointer;transition:.2s;
  background:none;border-top:none;border-left:none;border-right:none;white-space:nowrap;
}
.cat-pill:hover{color:var(--text)}
.cat-pill.on{color:var(--gold2);border-bottom-color:var(--gold2);font-weight:600}
.cat-cnt{background:rgba(200,151,42,.12);color:var(--gold);border-radius:6px;padding:1px 7px;font-size:10px;font-weight:700}

/* ─── MENU SECTION ──────────────────────────────────── */
.menu-section{background:var(--bg);padding:40px 0 200px}
.menu-wrap{max-width:1100px;margin:0 auto;padding:0 5%;display:flex;gap:28px}
.menu-col{flex:1;min-width:0}

/* Search */
.search-wrap{position:relative;margin-bottom:28px}
.search-input{
  width:100%;background:var(--card);border:1px solid var(--border);
  border-radius:12px;padding:12px 16px 12px 46px;
  color:var(--text);font-size:14px;transition:.2s;
}
.search-input:focus{outline:none;border-color:rgba(200,151,42,.35);background:var(--s2)}
.search-input::placeholder{color:var(--muted)}
.search-icon{position:absolute;left:16px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:17px}

/* Section heading */
.menu-sec{margin-bottom:40px}
.ms-head{display:flex;align-items:center;gap:12px;margin-bottom:18px;padding-bottom:12px;border-bottom:1px solid var(--border)}
.ms-emoji{font-size:24px}
.ms-title{font-family:'Playfair Display',serif;font-size:20px;font-weight:700}
.ms-cnt{font-size:11px;color:var(--muted);background:rgba(255,255,255,.05);border-radius:6px;padding:2px 8px}

/* ─── MENU ITEM CARD ───── OpenRice / chola.lk style ── */
.item-card{
  display:flex;align-items:stretch;gap:14px;
  background:var(--card);border:1px solid var(--border);
  border-radius:14px;padding:14px;margin-bottom:10px;
  cursor:pointer;transition:all .25s;position:relative;overflow:hidden;
}
.item-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:0;background:var(--item-color,var(--gold));transition:width .25s;opacity:.7}
.item-card:hover{border-color:rgba(200,151,42,.2);background:var(--s2);transform:translateX(4px)}
.item-card:hover::before{width:3px}
.item-thumb{
  width:90px;height:90px;border-radius:10px;flex-shrink:0;overflow:hidden;
  background:var(--s2);display:flex;align-items:center;justify-content:center;font-size:38px;
  position:relative;
}
.item-thumb img{width:100%;height:100%;object-fit:cover}
.item-body{flex:1;min-width:0;display:flex;flex-direction:column;justify-content:space-between}
.item-cat{font-size:10px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;margin-bottom:3px;opacity:.8}
.item-name{font-weight:700;font-size:15px;line-height:1.3;margin-bottom:4px}
.item-desc{font-size:12px;color:var(--muted);line-height:1.55;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.item-foot{display:flex;align-items:center;justify-content:space-between;margin-top:8px}
.item-price{font-family:'JetBrains Mono',monospace;font-weight:700;font-size:16px;color:var(--gold2)}
.item-price small{font-size:10px;color:var(--muted);font-weight:400;margin-right:1px}
.add-btn{
  width:34px;height:34px;border-radius:50%;border:none;
  font-size:20px;font-weight:700;cursor:pointer;color:#09090f;
  display:flex;align-items:center;justify-content:center;
  transition:all .2s;flex-shrink:0;
  box-shadow:0 3px 10px rgba(0,0,0,.25);
}
.add-btn:hover{transform:scale(1.12)}
.item-qty-ctrl{display:none;align-items:center;gap:7px;flex-shrink:0}
.qb{width:28px;height:28px;border-radius:50%;border:none;font-size:15px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.15s}
.qb-m{background:rgba(239,68,68,.12);color:var(--red)}
.qb-p{background:rgba(16,185,129,.12);color:var(--green)}
.qb-m:hover{background:rgba(239,68,68,.25)} .qb-p:hover{background:rgba(16,185,129,.25)}
.qb-n{font-size:14px;font-weight:800;min-width:20px;text-align:center;color:var(--gold2)}

/* ─── SIDEBAR CART (desktop) ─────────────────────────── */
.cart-col{width:300px;flex-shrink:0}
.cart-stick{
  position:sticky;top:130px;
  background:var(--card);border:1px solid var(--border);border-radius:18px;overflow:hidden;
}
.cart-head{
  padding:16px 18px;border-bottom:1px solid var(--border);
  background:linear-gradient(135deg,rgba(200,151,42,.08),transparent);
  display:flex;align-items:center;justify-content:space-between;
}
.cart-title{font-family:'Playfair Display',serif;font-size:16px;font-weight:700}
.cart-badge{background:var(--gold);color:#09090f;border-radius:100px;padding:2px 8px;font-size:11px;font-weight:800;display:none}
.cart-body{padding:12px 16px;min-height:80px;max-height:280px;overflow-y:auto}
.cart-empty-msg{text-align:center;padding:24px 10px;color:var(--muted);font-size:13px}
.ci{display:flex;align-items:center;gap:9px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.04)}
.ci-em{font-size:20px;width:28px;text-align:center;flex-shrink:0}
.ci-info{flex:1;min-width:0}
.ci-n{font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ci-p{font-size:11px;color:var(--muted);font-family:'JetBrains Mono',monospace}
.ci-ctrl{display:flex;align-items:center;gap:4px;flex-shrink:0}
.cib{width:22px;height:22px;border-radius:50%;border:none;font-size:13px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.15s}
.cib-m{background:rgba(239,68,68,.1);color:var(--red)} .cib-p{background:rgba(16,185,129,.1);color:var(--green)}
.cib-m:hover{background:rgba(239,68,68,.25)} .cib-p:hover{background:rgba(16,185,129,.25)}
.ci-q{font-size:12px;font-weight:800;min-width:16px;text-align:center;color:var(--gold2)}
.ci-t{font-size:12px;font-weight:700;font-family:'JetBrains Mono',monospace;color:var(--gold2);min-width:60px;text-align:right}

.cart-sum{padding:12px 16px;border-top:1px solid var(--border)}
.cs-r{display:flex;justify-content:space-between;font-size:12px;color:var(--muted);margin-bottom:4px}
.cs-t{display:flex;justify-content:space-between;font-size:15px;font-weight:800;margin-top:8px;padding-top:8px;border-top:1px solid var(--border)}
.cs-t .v{color:var(--gold2);font-family:'JetBrains Mono',monospace}
.cart-cta{
  width:100%;padding:13px;border:none;
  background:linear-gradient(135deg,var(--gold),var(--gold2));
  color:#09090f;font-weight:700;font-size:14px;cursor:pointer;transition:.2s;
}
.cart-cta:hover{opacity:.9}
.cart-cta:disabled{opacity:.4;cursor:not-allowed}

/* ─── RESERVATION SECTION ───────────────────────────── */
.reserve-section{
  padding:80px 5%;
  background:linear-gradient(170deg,#0a0602 0%,var(--s1) 100%);
  border-top:1px solid var(--border);
}
.reserve-inner{max-width:900px;margin:0 auto}
.section-tag{font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--gold);margin-bottom:8px;text-align:center}
.section-title{font-family:'Playfair Display',serif;font-size:clamp(28px,4vw,40px);font-weight:700;text-align:center;margin-bottom:8px}
.section-sub{font-size:14px;color:var(--muted);text-align:center;margin-bottom:40px;line-height:1.7}

.res-form{
  background:var(--card);border:1px solid var(--border);
  border-radius:20px;padding:36px;
}
.res-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}
.rf-group{display:flex;flex-direction:column;gap:7px}
.rf-label{font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--muted)}
.rf-input{
  background:var(--s2);border:1.5px solid var(--border);border-radius:11px;
  padding:12px 16px;color:var(--text);font-size:14px;transition:.2s;width:100%;
}
.rf-input:focus{outline:none;border-color:rgba(200,151,42,.4);background:rgba(200,151,42,.04)}
.rf-input::placeholder{color:var(--muted)}
textarea.rf-input{resize:none;height:80px}
.res-submit{
  width:100%;padding:15px;border:none;border-radius:12px;
  background:linear-gradient(135deg,var(--gold),var(--gold2));
  color:#09090f;font-weight:800;font-size:15px;cursor:pointer;transition:.2s;margin-top:6px;
}
.res-submit:hover{opacity:.9;transform:scale(1.01)}
.res-submit:disabled{opacity:.45;cursor:not-allowed}

/* Reservation success */
.res-success{
  display:none;text-align:center;padding:30px;
}
.rs-icon{font-size:56px;margin-bottom:12px;animation:pop .5s ease}
@keyframes pop{from{transform:scale(0)}to{transform:scale(1)}}
.rs-title{font-family:'Playfair Display',serif;font-size:24px;font-weight:700;color:var(--green);margin-bottom:6px}
.rs-msg{font-size:14px;color:var(--muted);line-height:1.7;margin-bottom:20px}
.rs-reset{padding:10px 28px;background:var(--gold);color:#09090f;border:none;border-radius:100px;font-weight:700;cursor:pointer}

/* ─── INFO SECTION ──────────────────────────────────── */
.info-section{padding:60px 5%;background:var(--s1);border-top:1px solid var(--border)}
.info-grid{max-width:1100px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px}
.info-card{
  background:var(--card);border:1px solid var(--border);
  border-radius:16px;padding:24px 20px;text-align:center;
}
.info-icon{font-size:30px;margin-bottom:10px}
.info-title{font-family:'Playfair Display',serif;font-size:16px;font-weight:700;color:var(--gold2);margin-bottom:6px}
.info-text{font-size:12.5px;color:var(--muted);line-height:1.7}

/* ─── FOOTER ────────────────────────────────────────── */
.footer{
  background:var(--bg);border-top:1px solid var(--border);
  padding:40px 5% 28px;
}
.foot-inner{max-width:1100px;margin:0 auto;display:grid;grid-template-columns:2fr 1fr 1fr;gap:40px;margin-bottom:28px}
.foot-brand{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--gold2);margin-bottom:8px}
.foot-desc{font-size:12.5px;color:var(--muted);line-height:1.8}
.foot-label{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);margin-bottom:10px}
.foot-item{font-size:13px;color:rgba(232,232,240,.55);margin-bottom:6px;display:flex;align-items:center;gap:8px}
.foot-bottom{max-width:1100px;margin:0 auto;padding-top:20px;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
.foot-copy{font-size:11.5px;color:var(--muted)}
.foot-power{font-size:11px;color:rgba(255,255,255,.1)}

/* ─── MOBILE CART FAB ─────────────────────────────── */
.mob-fab-wrap{position:fixed;bottom:0;left:0;right:0;z-index:700;padding:16px 20px 20px;background:linear-gradient(to top,var(--bg) 40%,transparent);pointer-events:none;display:flex;justify-content:center}
.mob-fab{
  pointer-events:auto;display:none;align-items:center;justify-content:space-between;
  width:100%;max-width:400px;
  background:linear-gradient(135deg,var(--gold),var(--gold2));
  color:#09090f;font-weight:700;font-size:14px;border:none;border-radius:100px;
  padding:14px 22px;cursor:pointer;box-shadow:0 6px 28px rgba(200,151,42,.4);
  transition:all .3s;
}
.mob-fab.show{display:flex;animation:fabUp .3s ease}
@keyframes fabUp{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}}
.mf-left{display:flex;align-items:center;gap:8px}
.mf-badge{background:#09090f;color:var(--gold);border-radius:100px;padding:2px 8px;font-size:11px;font-weight:800}

/* ─── DRAWER ────────────────────────────────────────── */
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:800;display:none;backdrop-filter:blur(8px)}
.overlay.show{display:block}
.drawer{
  position:fixed;right:0;top:0;bottom:0;width:min(420px,100vw);
  background:var(--s1);z-index:900;
  display:flex;flex-direction:column;
  transform:translateX(100%);transition:transform .35s cubic-bezier(.4,0,.2,1);
  border-left:1px solid var(--border);
}
.drawer.show{transform:translateX(0)}
.dr-head{padding:18px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.dr-title{font-family:'Playfair Display',serif;font-size:18px;font-weight:700}
.dr-x{width:32px;height:32px;border-radius:50%;border:1px solid var(--border);background:transparent;color:var(--muted);cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;transition:.15s}
.dr-x:hover{border-color:var(--red);color:var(--red)}
.dr-body{flex:1;overflow-y:auto;padding:12px 20px}
.dr-empty{text-align:center;padding:44px 20px;color:var(--muted)}
.dri{display:flex;align-items:center;gap:11px;padding:11px 0;border-bottom:1px solid rgba(255,255,255,.04)}
.dri-em{font-size:26px;flex-shrink:0;width:40px;text-align:center}
.dri-info{flex:1;min-width:0}
.dri-n{font-size:13px;font-weight:600}
.dri-p{font-size:11px;color:var(--muted);font-family:'JetBrains Mono',monospace}
.dri-ctrl{display:flex;align-items:center;gap:6px;flex-shrink:0}
.drb{width:26px;height:26px;border-radius:50%;border:none;font-size:14px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.15s}
.drb-m{background:rgba(239,68,68,.1);color:var(--red)} .drb-p{background:rgba(16,185,129,.1);color:var(--green)}
.drb-m:hover{background:rgba(239,68,68,.25)} .drb-p:hover{background:rgba(16,185,129,.25)}
.drq{font-size:13px;font-weight:800;min-width:16px;text-align:center;color:var(--gold2)}
.dri-t{font-size:13px;font-weight:700;font-family:'JetBrains Mono',monospace;color:var(--gold2);min-width:68px;text-align:right}
.dr-foot{border-top:1px solid var(--border);padding:14px 20px;flex-shrink:0}
.drs-r{display:flex;justify-content:space-between;font-size:12px;color:var(--muted);margin-bottom:4px}
.drs-t{display:flex;justify-content:space-between;font-size:16px;font-weight:800;margin-top:9px;padding-top:9px;border-top:1px solid var(--border)}
.drs-t .v{color:var(--gold2);font-family:'JetBrains Mono',monospace}
.dr-cta{width:100%;padding:13px;border:none;border-radius:11px;margin-top:11px;background:linear-gradient(135deg,var(--gold),var(--gold2));color:#09090f;font-weight:800;font-size:14px;cursor:pointer;transition:.2s}
.dr-cta:hover{opacity:.9}

/* ─── CHECKOUT SHEET ─────────────────────────────────── */
.co-bg{position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:1000;display:none;align-items:flex-end;justify-content:center;backdrop-filter:blur(12px)}
.co-bg.show{display:flex}
.co-sheet{
  background:var(--card);border-radius:24px 24px 0 0;
  width:min(560px,100vw);max-height:95vh;overflow-y:auto;
  padding:28px 26px 50px;
  transform:translateY(100%);transition:transform .4s cubic-bezier(.4,0,.2,1);
}
.co-bg.show .co-sheet{transform:translateY(0)}
.co-bar{width:36px;height:4px;background:rgba(255,255,255,.1);border-radius:2px;margin:0 auto 20px}
.co-title{font-family:'Playfair Display',serif;font-size:22px;font-weight:700;text-align:center;margin-bottom:4px}
.co-sub{font-size:12.5px;color:var(--muted);text-align:center;margin-bottom:24px}
.field{margin-bottom:14px}
.fl{display:block;font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--muted);margin-bottom:6px}
.fi{width:100%;background:var(--s2);border:1.5px solid var(--border);border-radius:11px;padding:12px 15px;color:var(--text);font-size:14px;transition:.2s}
.fi:focus{outline:none;border-color:rgba(200,151,42,.4);background:rgba(200,151,42,.04)}
.fi::placeholder{color:var(--muted)}
.fi.err{border-color:var(--red)}
textarea.fi{resize:none;height:64px}
.pay-opts{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:20px}
.pay-opt{border:2px solid var(--border);border-radius:12px;padding:14px 8px;text-align:center;cursor:pointer;transition:.2s;background:transparent}
.pay-opt:hover{border-color:rgba(200,151,42,.3)}
.pay-opt.on{border-color:var(--gold);background:rgba(200,151,42,.07)}
.po-icon{font-size:24px;margin-bottom:6px;display:block}
.po-lbl{font-size:11px;font-weight:700;color:var(--muted);line-height:1.4}
.pay-opt.on .po-lbl{color:var(--gold2)}
.order-sum{background:var(--s2);border-radius:12px;padding:14px;margin-bottom:16px}
.os-r{display:flex;justify-content:space-between;font-size:12.5px;padding:3px 0}
.os-n{color:var(--muted)} .os-v{font-weight:600;font-family:'JetBrains Mono',monospace;color:var(--gold2)}
.os-hr{border:none;border-top:1px solid var(--border);margin:8px 0}
.os-tot{display:flex;justify-content:space-between;font-weight:800;font-size:15px}
.place-btn{width:100%;padding:15px;border:none;border-radius:12px;background:linear-gradient(135deg,var(--green),#059669);color:#002a1e;font-weight:800;font-size:15px;cursor:pointer;transition:.2s;display:flex;align-items:center;justify-content:center;gap:8px;margin-top:4px}
.place-btn:hover{opacity:.9}
.place-btn:disabled{opacity:.45;cursor:not-allowed}

/* ─── SUCCESS SCREENS ─────────────────────────────── */
.suc-wrap{text-align:center;padding:16px 0}
.suc-icon{font-size:68px;margin-bottom:12px;animation:popBounce .6s ease}
@keyframes popBounce{from{transform:scale(0) rotate(-15deg)}to{transform:scale(1) rotate(0)}}
.suc-title{font-family:'Playfair Display',serif;font-size:26px;font-weight:900;margin-bottom:6px}
.suc-no{font-size:16px;font-family:'JetBrains Mono',monospace;font-weight:700;color:var(--gold2);margin-bottom:12px}
.suc-msg{font-size:13px;color:var(--muted);line-height:1.7;margin-bottom:24px}
.suc-close{padding:12px 32px;background:var(--gold);color:#09090f;border:none;border-radius:100px;font-weight:700;font-size:14px;cursor:pointer}

/* ─── RESPONSIVE ────────────────────────────────────── */
@media(max-width:960px){
  .about-inner{grid-template-columns:1fr;gap:32px}
  .about-visual{grid-template-columns:repeat(4,1fr)}
  .cart-col{display:none}
  .mob-fab{display:flex}
  .foot-inner{grid-template-columns:1fr 1fr}
}
@media(max-width:768px){
  .nav-links{display:none}
  .nav-reserve{display:none}
  .nav-cart-btn{display:none}
  .hamburger{display:flex}
  .res-grid{grid-template-columns:1fr}
  .foot-inner{grid-template-columns:1fr}
  .pay-opts{grid-template-columns:1fr}
  .about-visual{grid-template-columns:repeat(2,1fr)}
}
@media(max-width:540px){
  .hero-features{flex-wrap:wrap}
  .hf-item{min-width:45%}
  .menu-wrap{padding:0 14px}
  .item-thumb{width:72px;height:72px;font-size:30px}
  .item-name{font-size:13.5px}
  .res-form{padding:22px 18px}
  .co-sheet{padding:20px 16px 46px}
}
</style>
</head>
<body>

<!-- ══ NAVBAR ══════════════════════════════════════════ -->
<nav class="navbar" id="navbar">
  <div class="nav-brand"><?=htmlspecialchars($bizName)?></div>
  <div class="nav-links">
    <button class="nav-link active" onclick="goTo('home')">Home</button>
    <button class="nav-link" onclick="goTo('menu-section')">Menu</button>
    <button class="nav-link" onclick="goTo('reserve-section')">Reservations</button>
    <button class="nav-link" onclick="goTo('info-section')">Find Us</button>
  </div>
  <div style="display:flex;align-items:center;gap:10px">
    <button class="nav-cart-btn hidden" id="navCart" onclick="openDrawer()">
      🛒 Cart <span class="nav-badge" id="navCount">0</span>
    </button>
    <button class="nav-reserve" onclick="goTo('reserve-section')">Book a Table</button>
    <button class="hamburger" id="hamburger" onclick="toggleMob()">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<!-- Mobile menu -->
<div class="mob-menu" id="mobMenu">
  <button class="mob-link" onclick="goTo('home');toggleMob()">Home</button>
  <button class="mob-link" onclick="goTo('menu-section');toggleMob()">Menu</button>
  <button class="mob-link" onclick="goTo('reserve-section');toggleMob()">Reservations</button>
  <button class="mob-link" onclick="goTo('info-section');toggleMob()">Find Us</button>
  <button class="mob-reserve" onclick="goTo('reserve-section');toggleMob()">📅 Book a Table</button>
</div>

<!-- ══ HERO ════════════════════════════════════════════ -->
<section class="hero" id="home">
  <div class="hero-bg"></div>
  <div class="hero-pattern"></div>
  <div class="hero-glow1"></div>
  <div class="hero-glow2"></div>
  <div class="hero-inner">
    <div class="hero-badge"><div class="h-dot"></div>Now Taking Orders &amp; Reservations</div>
    <h1 class="hero-title">
      <span class="ht1"><?=htmlspecialchars($bizName)?></span>
      <span class="ht2">Taste the Authentic Flavours</span>
    </h1>
    <p class="hero-tagline">
      <?php if($bizAddr): ?>📍 <?=htmlspecialchars($bizAddr)?><?php endif; ?>
      <?php if($bizPhone): ?> &nbsp;·&nbsp; 📞 <?=htmlspecialchars($bizPhone)?><?php endif; ?><br>
      Experience the finest dining — browse our menu, place an order, or book your table online.
    </p>
    <div class="hero-divider"><div class="hero-divider-icon">✦</div></div>
    <div class="hero-btns">
      <button class="btn-gold" onclick="goTo('menu-section')">🍽 View Menu</button>
      <button class="btn-ghost" onclick="goTo('reserve-section')">📅 Book a Table</button>
    </div>
    <div class="hero-features">
      <div class="hf-item"><div class="hf-icon">🍽</div><div class="hf-label"><?=count($allItems)?> Dishes</div></div>
      <div class="hf-item"><div class="hf-icon">⚡</div><div class="hf-label">Order Online</div></div>
      <div class="hf-item"><div class="hf-icon">📅</div><div class="hf-label">Reserve Table</div></div>
      <div class="hf-item"><div class="hf-icon">🥡</div><div class="hf-label">Takeaway</div></div>
    </div>
  </div>
</section>

<!-- ══ ABOUT ════════════════════════════════════════════ -->
<section class="about-section">
  <div class="about-inner">
    <div>
      <div class="about-tag">Our Story</div>
      <h2 class="about-title">A Place Where Every Meal Becomes a Memory</h2>
      <p class="about-text">We take pride in serving food that is made with the finest ingredients, prepared with passion, and presented with care. Every dish tells a story of tradition, love, and culinary excellence.</p>
      <div class="about-list">
        <div class="about-item">Fresh ingredients sourced daily</div>
        <div class="about-item">Prepared by experienced chefs</div>
        <div class="about-item">Dine in, takeaway, and online ordering</div>
        <div class="about-item">Table reservations available</div>
      </div>
      <button class="btn-gold" onclick="goTo('menu-section')">Explore Our Menu</button>
    </div>
    <div class="about-visual">
      <div class="about-card"><div class="about-card-icon">🍽</div><div class="about-card-num"><?=count($allItems)?></div><div class="about-card-lbl">Dishes</div></div>
      <div class="about-card"><div class="about-card-icon">📂</div><div class="about-card-num"><?=count($categories)?></div><div class="about-card-lbl">Categories</div></div>
      <div class="about-card"><div class="about-card-icon">⭐</div><div class="about-card-num">5★</div><div class="about-card-lbl">Quality</div></div>
      <div class="about-card"><div class="about-card-icon">🕐</div><div class="about-card-num">7</div><div class="about-card-lbl">Days Open</div></div>
    </div>
  </div>
</section>

<!-- ══ CATEGORY NAV ══════════════════════════════════════ -->
<div class="cat-section" id="menu-section">
  <div class="cat-inner">
    <button class="cat-pill on" data-cat="all" onclick="filterCat(this,'all')">🍽 All <span class="cat-cnt"><?=count($allItems)?></span></button>
    <?php foreach($categories as $c): if(empty($byCategory[$c['id']])) continue; ?>
    <button class="cat-pill" data-cat="<?=$c['id']?>" onclick="filterCat(this,'<?=$c['id']?>')"><?=catEmoji($c['name'])?> <?=htmlspecialchars($c['name'])?> <span class="cat-cnt"><?=count($byCategory[$c['id']])?></span></button>
    <?php endforeach; ?>
  </div>
</div>

<!-- ══ MENU ══════════════════════════════════════════════ -->
<div class="menu-section">
  <div class="menu-wrap">
    <!-- Items column -->
    <div class="menu-col">
      <div class="search-wrap">
        <span class="search-icon">🔍</span>
        <input type="text" class="search-input" placeholder="Search dishes..." oninput="searchMenu(this.value)">
      </div>

      <?php if(empty($allItems)): ?>
        <div style="text-align:center;padding:60px;color:var(--muted)"><div style="font-size:48px;margin-bottom:12px">🍽</div>Menu coming soon!</div>
      <?php endif; ?>

      <?php $pi=0; foreach($categories as $c): if(empty($byCategory[$c['id']])) continue;
        $col=$PALETTE[$pi%count($PALETTE)]; $pi++; $em=catEmoji($c['name']); ?>
      <div class="menu-sec cat-section-block" data-cat="<?=$c['id']?>" id="sec-<?=$c['id']?>">
        <div class="ms-head">
          <span class="ms-emoji"><?=$em?></span>
          <span class="ms-title" style="color:<?=$col?>"><?=htmlspecialchars($c['name'])?></span>
          <span class="ms-cnt"><?=count($byCategory[$c['id']])?></span>
        </div>
        <?php foreach($byCategory[$c['id']] as $item): ?>
        <div class="item-card item-searchable"
             style="--item-color:<?=$col?>"
             data-id="<?=$item['id']?>"
             data-search="<?=strtolower(htmlspecialchars($item['name'].' '.$item['description'].' '.$c['name']))?>"
             onclick="addItem(<?=$item['id']?>,<?=htmlspecialchars(json_encode($item['name']))?>,<?=$item['price']?>,<?=htmlspecialchars(json_encode($em))?>,<?=htmlspecialchars(json_encode($col))?>)">
          <div class="item-thumb">
            <?php if(!empty($item['image']) && file_exists(__DIR__.'/assets/uploads/menu/'.$item['image'])): ?>
              <img src="assets/uploads/menu/<?=htmlspecialchars($item['image'])?>" alt="<?=htmlspecialchars($item['name'])?>">
            <?php else: ?>
              <?=$em?>
            <?php endif; ?>
          </div>
          <div class="item-body">
            <div>
              <div class="item-cat" style="color:<?=$col?>"><?=htmlspecialchars($c['name'])?></div>
              <div class="item-name"><?=htmlspecialchars($item['name'])?></div>
              <div class="item-desc"><?=htmlspecialchars($item['description']?:'Made fresh to order.')?></div>
            </div>
            <div class="item-foot">
              <div class="item-price"><small>Rs.</small><?=number_format($item['price'],2)?></div>
              <div class="item-qty-ctrl" id="qc-<?=$item['id']?>">
                <button class="qb qb-m" onclick="event.stopPropagation();chCard(<?=$item['id']?>,-1)">−</button>
                <span class="qb-n" id="qn-<?=$item['id']?>">0</span>
                <button class="qb qb-p" onclick="event.stopPropagation();chCard(<?=$item['id']?>,1)">+</button>
              </div>
              <button class="add-btn" id="ab-<?=$item['id']?>"
                style="background:linear-gradient(135deg,<?=$col?>,<?=$col?>bb)"
                onclick="event.stopPropagation();addItem(<?=$item['id']?>,<?=htmlspecialchars(json_encode($item['name']))?>,<?=$item['price']?>,<?=htmlspecialchars(json_encode($em))?>,<?=htmlspecialchars(json_encode($col))?>)">+</button>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Desktop sidebar cart -->
    <div class="cart-col">
      <div class="cart-stick">
        <div class="cart-head">
          <div class="cart-title">🛒 Your Order</div>
          <span class="cart-badge" id="cartBadge">0</span>
        </div>
        <div class="cart-body" id="cartBody">
          <div class="cart-empty-msg">🛒 Add items to start your order</div>
        </div>
        <div id="cartSumWrap" style="display:none">
          <div class="cart-sum">
            <div class="cs-r"><span>Subtotal</span><span id="csSub">Rs. 0.00</span></div>
            <div class="cs-r"><span>Service (<?=$svcPct?>%)</span><span id="csSvc">Rs. 0.00</span></div>
            <div class="cs-r"><span>Tax (<?=$taxPct?>%)</span><span id="csTax">Rs. 0.00</span></div>
            <div class="cs-t"><span>Total</span><span class="v" id="csTot">Rs. 0.00</span></div>
          </div>
          <button class="cart-cta" onclick="openCheckout()">Checkout →</button>
        </div>
        <div id="cartCtaEmpty"><button class="cart-cta" disabled>Add items to order</button></div>
      </div>
    </div>
  </div>
</div>

<!-- ══ RESERVATION ══════════════════════════════════════ -->
<section class="reserve-section" id="reserve-section">
  <div class="reserve-inner">
    <div class="section-tag">Table Booking</div>
    <h2 class="section-title">Reserve Your Table</h2>
    <p class="section-sub">Book a table in advance and we'll make sure everything is perfect for your visit.<?=$bizPhone?' Call us at '.htmlspecialchars($bizPhone).' or fill the form below.':''?></p>
    <div class="res-form" id="resFormWrap">
      <div class="res-grid">
        <div class="rf-group"><label class="rf-label">Your Name *</label><input type="text" class="rf-input" id="rName" placeholder="Full name"></div>
        <div class="rf-group"><label class="rf-label">Phone Number *</label><input type="tel" class="rf-input" id="rPhone" placeholder="07X XXX XXXX"></div>
        <div class="rf-group"><label class="rf-label">Date *</label><input type="date" class="rf-input" id="rDate" min="<?=date('Y-m-d')?>"></div>
        <div class="rf-group"><label class="rf-label">Number of Guests *</label>
          <select class="rf-input" id="rPax">
            <?php for($i=1;$i<=20;$i++): ?><option value="<?=$i?>" <?=$i==2?'selected':''?>><?=$i?> Guest<?=$i>1?'s':''?></option><?php endfor; ?>
          </select>
        </div>
        <div class="rf-group"><label class="rf-label">Start Time *</label><input type="time" class="rf-input" id="rTime" oninput="calcDur()"></div>
        <div class="rf-group"><label class="rf-label">End Time <small style="font-weight:400;text-transform:none;letter-spacing:0">(optional)</small></label><input type="time" class="rf-input" id="rEndTime" oninput="calcDur()"></div>
      </div>
      <div id="resDur" style="display:none;background:rgba(200,151,42,.08);border:1px solid rgba(200,151,42,.2);border-radius:10px;padding:10px 14px;font-size:13px;font-weight:600;color:var(--gold2);margin-bottom:14px">⏱ Duration: <span id="resDurTxt"></span></div>
      <div class="rf-group" style="margin-bottom:14px"><label class="rf-label">Location / Table Preference</label><input type="text" class="rf-input" id="rLoc" placeholder="e.g. Window seat, Private room, Garden area"></div>
      <div class="rf-group" style="margin-bottom:18px"><label class="rf-label">Special Requests</label><textarea class="rf-input" id="rNote" placeholder="Occasion, allergies, special arrangements..."></textarea></div>
      <button class="res-submit" id="resBtn" onclick="submitReservation()">📅 Confirm Reservation</button>
    </div>
    <div class="res-success" id="resSuccess">
      <div class="rs-icon">🎉</div>
      <div class="rs-title">Reservation Confirmed!</div>
      <div class="rs-msg" id="rSuccessMsg">Your table has been booked. We look forward to seeing you!</div>
      <button class="rs-reset" onclick="resetResForm()">Make Another Booking</button>
    </div>
  </div>
</section>

<!-- ══ INFO ═════════════════════════════════════════════ -->
<section class="info-section" id="info-section">
  <div class="info-grid">
    <div class="info-card"><div class="info-icon">🕐</div><div class="info-title">Opening Hours</div><div class="info-text">Monday – Sunday<br>11:00 AM – 10:00 PM</div></div>
    <div class="info-card"><div class="info-icon">📍</div><div class="info-title">Location</div><div class="info-text"><?=htmlspecialchars($bizAddr?:'Colombo, Sri Lanka')?></div></div>
    <div class="info-card"><div class="info-icon">📞</div><div class="info-title">Contact</div><div class="info-text"><?=htmlspecialchars($bizPhone?:'Call us to make enquiries or reservations.')?></div></div>
    <div class="info-card"><div class="info-icon">💳</div><div class="info-title">Payment</div><div class="info-text">Cash on pickup<br>Card &amp; Bank Transfer<br>accepted</div></div>
  </div>
</section>

<!-- ══ FOOTER ════════════════════════════════════════════ -->
<footer class="footer">
  <div class="foot-inner">
    <div>
      <div class="foot-brand"><?=htmlspecialchars($bizName)?></div>
      <div class="foot-desc">Serving quality food made with passion. Browse our menu, place an order, or book your table online. We look forward to serving you.</div>
    </div>
    <div>
      <div class="foot-label">Contact</div>
      <?php if($bizAddr): ?><div class="foot-item">📍 <?=htmlspecialchars($bizAddr)?></div><?php endif; ?>
      <?php if($bizPhone): ?><div class="foot-item">📞 <?=htmlspecialchars($bizPhone)?></div><?php endif; ?>
    </div>
    <div>
      <div class="foot-label">Quick Links</div>
      <div class="foot-item" style="cursor:pointer" onclick="goTo('home')">→ Home</div>
      <div class="foot-item" style="cursor:pointer" onclick="goTo('menu-section')">→ Menu</div>
      <div class="foot-item" style="cursor:pointer" onclick="goTo('reserve-section')">→ Reserve a Table</div>
      <div class="foot-item" style="cursor:pointer" onclick="goTo('info-section')">→ Find Us</div>
    </div>
  </div>
  <div class="foot-bottom">
    <div class="foot-copy">© <?=date('Y')?> <?=htmlspecialchars($bizName)?>. All prices inclusive of taxes & service charge.</div>
    <div class="foot-power">Powered by RestoPOS Sri Lanka</div>
  </div>
</footer>

<!-- ══ MOBILE FAB ════════════════════════════════════════ -->
<div class="mob-fab-wrap">
  <button class="mob-fab" id="mobFab" onclick="openDrawer()">
    <div class="mf-left">🛒 <span>View Order</span> <span class="mf-badge" id="mobCount">0</span></div>
    <span id="mobTotal" style="font-family:'JetBrains Mono',monospace;font-size:13px">Rs. 0.00</span>
  </button>
</div>

<!-- ══ DRAWER ════════════════════════════════════════════ -->
<div class="overlay" id="overlay" onclick="closeDrawer()"></div>
<div class="drawer" id="drawer">
  <div class="dr-head">
    <div class="dr-title">Your Order</div>
    <button class="dr-x" onclick="closeDrawer()">✕</button>
  </div>
  <div class="dr-body" id="drBody"><div class="dr-empty">🛒 Cart is empty</div></div>
  <div class="dr-foot" id="drFoot" style="display:none">
    <div class="drs-r"><span>Subtotal</span><span id="drSub"></span></div>
    <div class="drs-r"><span>Service (<?=$svcPct?>%)</span><span id="drSvc"></span></div>
    <div class="drs-r"><span>Tax (<?=$taxPct?>%)</span><span id="drTax"></span></div>
    <div class="drs-t"><span>Total</span><span class="v" id="drTot"></span></div>
    <button class="dr-cta" onclick="closeDrawer();openCheckout()">Proceed to Checkout →</button>
  </div>
</div>

<!-- ══ CHECKOUT ══════════════════════════════════════════ -->
<div class="co-bg" id="coBg">
  <div class="co-sheet">
    <div id="coContent">
      <div class="co-bar"></div>
      <div class="co-title">Complete Your Order</div>
      <div class="co-sub">Fill your details and choose payment</div>
      <div class="field"><label class="fl">Full Name *</label><input type="text" class="fi" id="cName" placeholder="Your name"></div>
      <div class="field"><label class="fl">Phone Number *</label><input type="tel" class="fi" id="cPhone" placeholder="07X XXX XXXX"></div>
      <div class="field">
        <label class="fl">Payment Method</label>
        <div class="pay-opts">
          <div class="pay-opt on" data-pay="takeaway" onclick="selPay(this)"><span class="po-icon">🥡</span><div class="po-lbl">Takeaway<br><span style="font-weight:400;font-size:10px">Pay on pickup</span></div></div>
          <div class="pay-opt" data-pay="card" onclick="selPay(this)"><span class="po-icon">💳</span><div class="po-lbl">Card<br><span style="font-weight:400;font-size:10px">Online pay</span></div></div>
          <div class="pay-opt" data-pay="bank_transfer" onclick="selPay(this)"><span class="po-icon">🏦</span><div class="po-lbl">Bank Transfer<br><span style="font-weight:400;font-size:10px">Send slip</span></div></div>
        </div>
      </div>
      <div class="field"><label class="fl">Order Summary</label><div class="order-sum" id="coItems"></div></div>
      <div class="field"><label class="fl">Special Requests</label><textarea class="fi" id="cNote" placeholder="Allergies, spice level..."></textarea></div>
      <button class="place-btn" id="placeBtn" onclick="placeOrder()">✅ Place Order</button>
    </div>
    <div id="coSuccess" style="display:none" class="suc-wrap">
      <div class="suc-icon">🎉</div>
      <div class="suc-title" style="color:var(--green)">Order Placed!</div>
      <div class="suc-no" id="sNo"></div>
      <div class="suc-msg">Your order has been received! Our team will prepare it shortly.<br><br>📞 We may call you at <strong id="sPh"></strong> to confirm.</div>
      <button class="suc-close" onclick="closeAll()">✓ Done</button>
    </div>
  </div>
</div>

<script>
// ── CART ────────────────────────────────────────────────
var cart={},payType='takeaway';
const SVC=<?=$svcPct?>/100,TAX=<?=$taxPct?>/100;
const Rs=n=>'Rs. '+parseFloat(n).toFixed(2);

function totals(){
  var items=Object.values(cart);
  var sub=items.reduce((s,i)=>s+i.price*i.qty,0);
  var svc=sub*SVC,tax=(sub+svc)*TAX,tot=sub+svc+tax;
  return{items,sub,svc,tax,tot,cnt:items.reduce((s,i)=>s+i.qty,0)};
}
function addItem(id,name,price,emoji,color){
  cart[id]=cart[id]?{...cart[id],qty:cart[id].qty+1}:{id,name,price,emoji,color,qty:1};
  syncCard(id);renderAll();
}
function chCard(id,d){
  if(!cart[id])return;
  cart[id].qty+=d;
  if(cart[id].qty<=0)delete cart[id];
  syncCard(id);renderAll();
}
function chPanel(id,d){chCard(id,d);renderPanel();}
function chDr(id,d){chCard(id,d);renderDrawer();}

function syncCard(id){
  var qty=cart[id]?cart[id].qty:0;
  var ab=document.getElementById('ab-'+id),qc=document.getElementById('qc-'+id),qn=document.getElementById('qn-'+id);
  if(!ab)return;
  if(qty>0){ab.style.display='none';qc.style.display='flex';qn.textContent=qty;}
  else{ab.style.display='';qc.style.display='none';}
}
function renderAll(){renderPanel();renderMobFab();}

function renderPanel(){
  var {items,sub,svc,tax,tot,cnt}=totals();
  var body=document.getElementById('cartBody'),sumWrap=document.getElementById('cartSumWrap'),
      ctaEmpty=document.getElementById('cartCtaEmpty'),badge=document.getElementById('cartBadge'),
      nc=document.getElementById('navCart');
  // nav
  if(cnt>0){nc.classList.remove('hidden');document.getElementById('navCount').textContent=cnt;}
  else nc.classList.add('hidden');
  badge.textContent=cnt;
  badge.style.display=cnt>0?'':'none';
  if(!items.length){
    body.innerHTML='<div class="cart-empty-msg">🛒 Add items to start your order</div>';
    sumWrap.style.display='none';ctaEmpty.style.display='';return;
  }
  ctaEmpty.style.display='none';sumWrap.style.display='';
  body.innerHTML=items.map(i=>`<div class="ci"><div class="ci-em">${i.emoji}</div><div class="ci-info"><div class="ci-n">${i.name}</div><div class="ci-p">${Rs(i.price)}</div></div><div class="ci-ctrl"><button class="cib cib-m" onclick="chPanel(${i.id},-1)">−</button><span class="ci-q">${i.qty}</span><button class="cib cib-p" onclick="chPanel(${i.id},1)">+</button></div><div class="ci-t">${Rs(i.price*i.qty)}</div></div>`).join('');
  document.getElementById('csSub').textContent=Rs(sub);
  document.getElementById('csSvc').textContent=Rs(svc);
  document.getElementById('csTax').textContent=Rs(tax);
  document.getElementById('csTot').textContent=Rs(tot);
}
function renderMobFab(){
  var {tot,cnt}=totals();
  var fab=document.getElementById('mobFab');
  document.getElementById('mobCount').textContent=cnt;
  document.getElementById('mobTotal').textContent=Rs(tot);
  cnt>0?fab.classList.add('show'):fab.classList.remove('show');
}

// ── DRAWER ───────────────────────────────────────────────
function openDrawer(){
  document.getElementById('overlay').classList.add('show');
  document.getElementById('drawer').classList.add('show');
  document.body.style.overflow='hidden';renderDrawer();
}
function closeDrawer(){
  document.getElementById('overlay').classList.remove('show');
  document.getElementById('drawer').classList.remove('show');
  document.body.style.overflow='';
}
function renderDrawer(){
  var {items,sub,svc,tax,tot}=totals();
  var body=document.getElementById('drBody'),foot=document.getElementById('drFoot');
  if(!items.length){body.innerHTML='<div class="dr-empty" style="text-align:center;padding:40px;color:var(--muted)">🛒 Cart is empty</div>';foot.style.display='none';return;}
  body.innerHTML=items.map(i=>`<div class="dri"><div class="dri-em">${i.emoji}</div><div class="dri-info"><div class="dri-n">${i.name}</div><div class="dri-p">${Rs(i.price)}</div></div><div class="dri-ctrl"><button class="drb drb-m" onclick="chDr(${i.id},-1)">−</button><span class="drq">${i.qty}</span><button class="drb drb-p" onclick="chDr(${i.id},1)">+</button></div><div class="dri-t">${Rs(i.price*i.qty)}</div></div>`).join('');
  foot.style.display='';
  document.getElementById('drSub').textContent=Rs(sub);
  document.getElementById('drSvc').textContent=Rs(svc);
  document.getElementById('drTax').textContent=Rs(tax);
  document.getElementById('drTot').textContent=Rs(tot);
}

// ── CHECKOUT ─────────────────────────────────────────────
function openCheckout(){
  var {items,sub,svc,tax,tot}=totals();
  document.getElementById('coItems').innerHTML=
    items.map(i=>`<div class="os-r"><span class="os-n">${i.qty}× ${i.name}</span><span class="os-v">${Rs(i.price*i.qty)}</span></div>`).join('')+
    `<hr class="os-hr"><div class="os-r"><span class="os-n">Service</span><span>${Rs(svc)}</span></div>`+
    `<div class="os-r"><span class="os-n">Tax</span><span>${Rs(tax)}</span></div>`+
    `<hr class="os-hr"><div class="os-tot"><span>Total</span><span class="os-v">${Rs(tot)}</span></div>`;
  document.getElementById('coContent').style.display='';
  document.getElementById('coSuccess').style.display='none';
  document.getElementById('coBg').classList.add('show');
  document.body.style.overflow='hidden';
}
function selPay(el){document.querySelectorAll('.pay-opt').forEach(p=>p.classList.remove('on'));el.classList.add('on');payType=el.dataset.pay;}
function placeOrder(){
  var name=document.getElementById('cName').value.trim();
  var phone=document.getElementById('cPhone').value.trim();
  ['cName','cPhone'].forEach(id=>document.getElementById(id).classList.remove('err'));
  if(!name){document.getElementById('cName').classList.add('err');document.getElementById('cName').focus();return;}
  if(!phone){document.getElementById('cPhone').classList.add('err');document.getElementById('cPhone').focus();return;}
  var btn=document.getElementById('placeBtn');
  btn.disabled=true;btn.innerHTML='⏳ Placing order...';
  var fd=new FormData();
  fd.append('place_order','1');
  fd.append('customer_name',name);fd.append('customer_phone',phone);
  fd.append('customer_note',document.getElementById('cNote').value.trim());
  fd.append('order_type',payType);
  fd.append('cart',JSON.stringify(Object.values(cart)));
  fetch('online_menu.php',{method:'POST',body:fd})
    .then(r=>r.json()).then(data=>{
      if(data.ok){
        document.getElementById('sNo').textContent='Order '+data.order_no;
        document.getElementById('sPh').textContent=phone;
        document.getElementById('coContent').style.display='none';
        document.getElementById('coSuccess').style.display='';
        cart={};
        document.querySelectorAll('.add-btn').forEach(b=>b.style.display='');
        document.querySelectorAll('.item-qty-ctrl').forEach(c=>c.style.display='none');
        renderAll();
      } else {
        alert(data.error||'Something went wrong. Try again.');
        btn.disabled=false;btn.innerHTML='✅ Place Order';
      }
    }).catch(()=>{alert('Network error. Check your connection.');btn.disabled=false;btn.innerHTML='✅ Place Order';});
}
function closeAll(){document.getElementById('coBg').classList.remove('show');document.body.style.overflow='';}
document.getElementById('coBg').addEventListener('click',function(e){if(e.target===this)closeAll();});

// ── RESERVATION ──────────────────────────────────────────
function calcDur(){
  var s=document.getElementById('rTime').value,e=document.getElementById('rEndTime').value;
  var box=document.getElementById('resDur'),txt=document.getElementById('resDurTxt');
  if(!s||!e){box.style.display='none';return;}
  var [sh,sm]=s.split(':').map(Number),[eh,em]=e.split(':').map(Number);
  var diff=(eh*60+em)-(sh*60+sm);
  if(diff<=0){txt.textContent='⚠ End time must be after start';box.style.display='';return;}
  var h=Math.floor(diff/60),m=diff%60;
  txt.textContent=(h>0?h+' hour'+(h>1?'s':''):'')+(h&&m?' ':'')+(m>0?m+' min':'');
  box.style.display='';
}
function submitReservation(){
  var name=document.getElementById('rName').value.trim();
  var phone=document.getElementById('rPhone').value.trim();
  var date=document.getElementById('rDate').value;
  var time=document.getElementById('rTime').value;
  if(!name||!phone||!date||!time){
    alert('Please fill in your name, phone, date and time.');return;
  }
  var btn=document.getElementById('resBtn');
  btn.disabled=true;btn.innerHTML='⏳ Confirming...';
  var fd=new FormData();
  fd.append('make_reservation','1');
  fd.append('res_name',name);fd.append('res_phone',phone);
  fd.append('res_date',date);fd.append('res_time',time);
  fd.append('res_end_time',document.getElementById('rEndTime').value);
  fd.append('res_pax',document.getElementById('rPax').value);
  fd.append('res_location',document.getElementById('rLoc').value.trim());
  fd.append('res_note',document.getElementById('rNote').value.trim());
  fetch('online_menu.php',{method:'POST',body:fd})
    .then(r=>r.json()).then(data=>{
      if(data.ok){
        document.getElementById('rSuccessMsg').innerHTML=
          `<strong>${data.name}</strong>, your table is reserved for <strong>${data.date}</strong> at <strong>${data.time}</strong>.<br>We look forward to seeing you! 📅`;
        document.getElementById('resFormWrap').style.display='none';
        document.getElementById('resSuccess').style.display='block';
      } else {
        alert(data.error||'Reservation failed. Please call us directly.');
        btn.disabled=false;btn.innerHTML='📅 Confirm Reservation';
      }
    }).catch(()=>{alert('Network error. Please call us directly.');btn.disabled=false;btn.innerHTML='📅 Confirm Reservation';});
}
function resetResForm(){
  document.getElementById('resFormWrap').style.display='';
  document.getElementById('resSuccess').style.display='none';
  document.getElementById('resBtn').disabled=false;
  document.getElementById('resBtn').innerHTML='📅 Confirm Reservation';
  ['rName','rPhone','rDate','rTime','rEndTime','rLoc','rNote'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('rPax').value=2;
  document.getElementById('resDur').style.display='none';
}

// ── NAV / SCROLL / FILTER ─────────────────────────────────
function goTo(id){
  var el=document.getElementById(id);
  if(el){var top=el.getBoundingClientRect().top+window.scrollY-80;window.scrollTo({top,behavior:'smooth'});}
}
function filterCat(el,catId){
  document.querySelectorAll('.cat-pill').forEach(p=>p.classList.remove('on'));
  el.classList.add('on');
  document.querySelectorAll('.cat-section-block').forEach(s=>s.style.display=catId==='all'||s.dataset.cat===catId?'':'none');
  if(catId!=='all'){
    var t=document.getElementById('sec-'+catId);
    if(t)setTimeout(()=>t.scrollIntoView({behavior:'smooth',block:'start'}),80);
  }
}
function searchMenu(q){
  q=q.toLowerCase().trim();
  document.querySelectorAll('.item-searchable').forEach(c=>{c.style.display=!q||c.dataset.search.includes(q)?'':'none';});
  if(q)document.querySelectorAll('.cat-section-block').forEach(s=>s.style.display='');
}
function toggleMob(){document.getElementById('mobMenu').classList.toggle('open');}
window.addEventListener('scroll',()=>{
  document.getElementById('navbar').classList.toggle('scrolled',window.scrollY>40);
  document.getElementById('mobMenu').classList.remove('open');
});
</script>
</body>
</html>
